# 知识索引与空间数学

Markdown链接/标签/模糊链接消歧、资料库扫描搜索、知识宫殿和漫游场景数学。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/knowledge-search
```

```js
const tools = require('@inkspace-modules/knowledge-search');
console.log(tools.links.tagsOf('#example [[Second note]]'));
```

## API 命名空间

- `links` → [源码与函数签名](sources/main/knowledge-service.cjs)
- `palace` → [源码与函数签名](sources/renderer/knowledge-palace-math.ts)
- `metadata` → [源码与函数签名](sources/renderer/knowledge-space-metadata.ts)
- `walkMath` → [源码与函数签名](sources/renderer/knowledge-walk-math.ts)
- `walkRenderer` → [源码与函数签名](sources/renderer/knowledge-walk-renderer.ts)
- `walkGL` → [源码与函数签名](sources/renderer/knowledge-walk-gl.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

链接与数学函数可直接使用；KnowledgeService扫描需注入授权资料库接口，WebGL实际绘制需调用者提供浏览器Canvas/WebGL2。无示例私人资料。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
