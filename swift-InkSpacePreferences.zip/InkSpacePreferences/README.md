# InkSpacePreferences

独立语言/布局、工具栏与笔栏、Pencil操作选择、字幕外观及播放偏好，显式隔离持久化。这是SwiftPM源码库，需要解压并加入自己的软件，不包含可直接启动的App或安装包。

## 本包内容

- 原模块名与对外产品名：`InkSpacePreferences`。
- 直接依赖：无其它InkSpace模块。
- 自带target闭包：`InkSpacePreferences`。
- 最低声明平台：macOS 13、iOS/iPadOS 18；Swift 5.9及以上。
- 库源码和资源与整合版模块集合中的对应文件逐字节一致；没有附带构建缓存、账号凭据或用户资料。

## 解压后使用

1. 解压这个ZIP，得到`InkSpacePreferences/Package.swift`和`Sources/`。
2. 在Xcode选择添加本地Swift Package，并选择这个解压后的文件夹。
3. 只选择`InkSpacePreferences`这个library product，代码使用`import InkSpacePreferences`。

## 先运行随包示例 / Run the included example

本ZIP的`Example/`包含独立macOS示例，只需要安装带Swift工具链的Xcode，不需要完整InkSpace、账号或密钥。在本包解压目录运行：

```sh
bash Example/script/build_and_run.sh
```

也可用`swift run --package-path Example InkSpacePreferencesDemo`直接从SwiftPM启动。

示例源码和详细操作见`Example/README.md`。这是从源码启动的示例，不是已签名安装包；iPhone/iPad使用方式和平台边界见下方说明。

也可以在自己的Package.swift中使用本地路径依赖：

```swift
.package(path: "../InkSpacePreferences")
```

自己的target依赖添加：

```swift
.product(name: "InkSpacePreferences", package: "inkspacepreferences")
```

在解压后的包目录运行`swift build`可编译此库。这个源码ZIP不是远程SwiftPM仓库地址；不能将ZIP下载链接当作`.package(url:)`地址。

## 公开API

- `InterfaceLanguage.initial(saved:preferredLanguages:)`
- `LanguagePreference.resolved(preferredLanguages:)`
- `PreferencesLocalizer.allKeys / text(_:language:fallback:)`
- `PanelLayoutPreferences.normalized / fitted(viewport:aiOpen:compactLeftOpen:)`
- `BoardToolbarFunction / BoardToolbarVisibility.setVisible(_:for:)`
- `SavedPenKind / SavedPen / SavedPenSettings.defaults / validate() / removingPen(_:)`
- `NativePaletteEntry / NativePaletteSettings.migrated(penIDs:) / reconciled(penIDs:) / reorderingPens(penIDs:) / moving(fromOffsets:toOffset:) / removing(_:) / restoringUtility(_:)`
- `BoardPencilGestureSettings / BoardPencilLineSettings.normalized / BoardPencilShapeSettings`
- `BoardPaletteDockSettings.frame(in:toolCount:)`
- `SubtitleAppearancePreferences.normalized / PlaybackPreferences.normalized`
- `ReplayDisplayMode.opacity(index:visibleCount:) / AIWebsitePreference / TranslationServicePreference`
- `PreferencesSnapshot.normalized()`
- `PreferencesStore.init(domain:storage:) / load() / save(_:)`
- `PreferencesDataStorage / MemoryPreferencesStorage / FilePreferencesStorage / UserDefaultsPreferencesStorage`

## 用法示例

源码附带可启动的 macOS 设置演示 `InkSpacePreferencesDemo`。在本独立下载包根目录运行：

```sh
bash Example/script/build_and_run.sh
```

脚本构建并启动有独立标识的 `.app`，给本机构建的示例添加临时ad-hoc签名，不使用Apple账号、个人证书或私钥；这不代表已经公证的公众安装包。也可进入示例 `Package.swift` 所在目录运行 `swift run InkSpacePreferencesDemo`，或在 Xcode 打开它运行。演示提供语言切换、面板宽度、14项工具栏显隐、笔预设/混排、Pencil动作与停留时间、字幕外观和播放偏好。

演示从七种初始笔样式与合成标识开始。默认仅使用系统临时目录下自己独立的 `InkSpacePreferencesDemo/settings.json`，存储域为 `com.example.inkspace.preferencesdemo`。点“保存”后重新读取，或退出重开，可验证持久化；临时目录可能被系统清理。正式产品请为 `FilePreferencesStorage` 提供自己的持久位置。不会读取完整App偏好或真实笔记。

在示例目录运行 `swift test` 可执行16项偏好行为测试。无界面持久化检查可用 `swift run InkSpacePreferencesDemo --self-test /tmp/preferences-synthetic.json`，再以另一个进程运行 `swift run InkSpacePreferencesDemo --verify-persistence /tmp/preferences-synthetic.json`；两次命令只访问明确指定的合成测试文件。

## 依赖与组合

本包只声明一个对外product，依赖target已经一并提供，因此无需安装完整InkSpace应用。多个不同ZIP可能自带相同的共享target，例如`InkSpacePaths`；需要在同一个项目组合这些功能时，使用完整模块集合的清单统一依赖，或统一共享target，不要同时引入重复的同名target。

## 范围与验证

这是偏好库与可启动macOS示例，不是完整InkSpace设置界面或书写引擎。iOS库支持不等于Apple Pencil硬件验收；事件、PencilKit工具、系统语言设置、原生字幕/播放/翻译/AI服务由宿主实现。没有新增全局主题或无障碍系统控制；示例跟随系统外观。原App存量偏好不会自动读取或迁移。多写者需宿主协调；本地配置不是密钥保险库。

初次抽取时的整合版16个Swift产品曾通过普通import构建、20项行为测试和iOS arm64模拟器无签名构建；后续源码更新不自动继承这些历史结论。独立归档重建会逐包检查SwiftPM产品、target依赖和资源闭包；额外编译由维护者显式选择。本包未附带或自动重新执行整合版全部行为测试，实际验证结果由维护者记入发布清单。未操作真实设备、真实AI服务或Keychain。

采用MIT许可，见LICENSE。
