// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpacePaths",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpacePaths", targets: ["InkSpacePaths"])],
    targets: [
        .target(name: "InkSpacePaths", path: "Sources/InkSpacePaths")
    ]
)
