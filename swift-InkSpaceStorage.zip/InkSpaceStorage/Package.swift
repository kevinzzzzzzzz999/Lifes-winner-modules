// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceStorage",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceStorage", targets: ["InkSpaceStorage"])],
    targets: [
        .target(name: "InkSpacePaths", path: "Sources/InkSpacePaths"),
        .target(name: "InkSpaceStorage", dependencies: ["InkSpacePaths"], path: "Sources/InkSpaceStorage")
    ]
)
