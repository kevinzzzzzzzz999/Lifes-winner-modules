# 文档链接与工作区状态

内部文档链接、文件树/标签状态、自动保存接受规则、文档缩放、快捷键、富文本和公式片段。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/document-workspace
```

```js
const tools = require('@inkspace-modules/document-workspace');
console.log(tools.links.internalFileAnchor('inkspace://open?file=notes%2Fexample.md'));
console.log(tools.zoom.clampDocumentZoom(10));
```

## API 命名空间

- `links` → [源码与函数签名](sources/shared/internal-file-links.ts)
- `tree` → [源码与函数签名](sources/renderer/file-tree-management.ts)
- `kinds` → [源码与函数签名](sources/renderer/workspace-file-kinds.ts)
- `tabs` → [源码与函数签名](sources/renderer/external-open-tabs.ts)
- `autosave` → [源码与函数签名](sources/renderer/autosave-tabs.ts)
- `zoom` → [源码与函数签名](sources/renderer/document-zoom.ts)
- `workspace` → [源码与函数签名](sources/renderer/PDFWorkspaceState.ts)
- `pagePreviews` → [源码与函数签名](sources/renderer/BoardPagePreviews.ts)
- `shortcuts` → [源码与函数签名](sources/renderer/app-shortcuts.ts)
- `menus` → [源码与函数签名](sources/main/document-menu.cjs)
- `contextMenu` → [源码与函数签名](sources/main/editable-context-menu.cjs)
- `richText` → [源码与函数签名](sources/renderer/clipboard-rich-text.ts)
- `math` → [源码与函数签名](sources/renderer/rich-text-math.ts)
- `exportView` → [源码与函数签名](sources/renderer/export-view.ts)
- `externalOpen` → [源码与函数签名](sources/main/external-document-open.cjs)
- `preparationDeadline` → [源码与函数签名](sources/renderer/office-preparation-deadline.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

- `katex@0.18.7`
- `marked@18.0.13`

## 使用边界

链接/缩放/状态规则是纯函数。富文本解析、公式HTML、Canvas导出与宿主菜单动作需要调用者提供DOM或宿主动作接口；本包不附带窗口、浏览器或编辑器UI。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：13 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
