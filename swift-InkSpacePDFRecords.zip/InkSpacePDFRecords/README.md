# InkSpacePDFRecords

PDF图层、批注和增页记录。这是SwiftPM源码库，需要解压并加入自己的软件，不包含可直接启动的App或安装包。

## 本包内容

- 技术模块名与product名：`InkSpacePDFRecords`。
- 直接依赖：无其它本项目模块。
- 自带target闭包：`InkSpacePDFRecords`。
- 最低声明平台：macOS 13、iOS/iPadOS 18；Swift 5.9及以上。
- 库源码和资源与整合版模块集合中的对应文件逐字节一致；没有附带构建缓存、账号凭据或用户资料。

## 解压后使用

1. 解压这个ZIP，得到`InkSpacePDFRecords/Package.swift`和`Sources/`。
2. 在Xcode选择添加本地Swift Package，并选择这个解压后的文件夹。
3. 只选择`InkSpacePDFRecords`这个library product，代码使用`import InkSpacePDFRecords`。

也可以在自己的Package.swift中使用本地路径依赖：

```swift
.package(path: "../InkSpacePDFRecords")
```

自己的target依赖添加：

```swift
.product(name: "InkSpacePDFRecords", package: "inkspacepdfrecords")
```

在解压后的包目录运行`swift build`可编译此库。这个源码ZIP不是远程SwiftPM仓库地址；不能将ZIP下载链接当作`.package(url:)`地址。

## 公开API

- `PDFWorkspaceEvent.make/decodeValidated/encoded`
- `PDFWorkspaceProjection.project`
- `PDFExtensionEvent.decodeValidated`
- `PDFExtensionGeometry.slices`

## 用法示例

示例中未定义的文件URL/数据由调用方提供；涉及throws/async的片段放入相应调用上下文。

```swift
import Foundation
import InkSpacePDFRecords
import CoreGraphics
let layer = PDFWorkspaceLayer(name: "Notes")
let event = try PDFWorkspaceEvent.make(layer: layer)
let checked = try PDFWorkspaceEvent.decodeValidated(event.encoded())
let view = PDFWorkspaceProjection.project([checked])
```

## 依赖与组合

本包只声明一个对外product，依赖target已经一并提供，因此无需安装完整版人生赢家应用。多个不同ZIP可能自带相同的共享target，例如`InkSpacePaths`；需要在同一个项目组合这些功能时，使用完整模块集合的清单统一依赖，或统一共享target，不要同时引入重复的同名target。

## 范围与验证

这是JSON记录、冲突投影和留白布局模块，不是PDF文件导出器。原生笔迹载荷仅作为有界opaque Data保存，不解析PencilKit。输入应经decodeValidated；事件投影前使用make/decodeValidated取得有效时间。

初次抽取时的整合版16个Swift产品曾通过普通import构建、20项行为测试和iOS arm64模拟器无签名构建；后续源码更新不自动继承这些历史结论。独立归档重建会逐包检查SwiftPM产品、target依赖和资源闭包；额外编译由维护者显式选择。本包未附带或自动重新执行整合版全部行为测试，实际验证结果由维护者记入发布清单。未操作真实设备、真实AI服务或Keychain。

采用MIT许可，见LICENSE。
