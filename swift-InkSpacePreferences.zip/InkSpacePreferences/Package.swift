// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpacePreferences",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpacePreferences", targets: ["InkSpacePreferences"])],
    targets: [
        .target(name: "InkSpacePreferences", path: "Sources/InkSpacePreferences")
    ]
)
