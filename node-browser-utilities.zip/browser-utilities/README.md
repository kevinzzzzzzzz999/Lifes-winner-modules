# 网页会话与链接工具

URL验证、文件链接路由、浏览会话存储、AI页面就绪检查、粘贴/下载与权限策略。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/browser-utilities
```

```js
const tools = require('@inkspace-modules/browser-utilities');
console.log(tools.urls.webURL('https://example.test'));
```

## API 命名空间

- `urls` → [源码与函数签名](sources/main/browser-security.cjs)
- `routing` → [源码与函数签名](sources/main/browser-link-routing.cjs)
- `sessions` → [源码与函数签名](sources/main/browser-state.cjs)
- `web` → [源码与函数签名](sources/main/board-web-url.cjs)
- `network` → [源码与函数签名](sources/main/board-web-network.cjs)
- `providers` → [源码与函数签名](sources/main/ai-web-providers.cjs)
- `pageHealth` → [源码与函数签名](sources/main/ai-page-health.cjs)
- `downloads` → [源码与函数签名](sources/main/ai-downloads.cjs)
- `mediaPermissions` → [源码与函数签名](sources/main/ai-media-permissions.cjs)
- `images` → [源码与函数签名](sources/main/ai-image-transfer.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

URL/会话数据处理可在Node使用；页面、权限、剪贴板等策略接受宿主对象，不附带浏览器界面或用户登录状态。需要真实浏览器的行为仍由调用者集成与验收。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：41 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
