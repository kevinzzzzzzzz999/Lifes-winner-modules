// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceOutline",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceOutline", targets: ["InkSpaceOutline"])],
    targets: [
        .target(name: "InkSpaceOutline", path: "Sources/InkSpaceOutline")
    ]
)
