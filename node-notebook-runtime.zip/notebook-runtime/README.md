# Python与IPython运行协议

显式运行Python、Notebook单元格读取与受限输出协议、重启和运行请求控制。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/notebook-runtime
```

```js
const tools = require('@inkspace-modules/notebook-runtime');
const data = Buffer.from(JSON.stringify({nbformat:4, metadata:{}, cells:[{cell_type:'code', source:['1+1']}]}));
console.log(tools.notebooks.readCells(data, [0]));
```

## API 命名空间

- `notebooks` → [源码与函数签名](sources/main/notebook-service.cjs)
- `python` → [源码与函数签名](sources/main/python-service.cjs)
- `runController` → [源码与函数签名](sources/renderer/notebook-run-controller.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

需显式提供Python解释器路径、IPython依赖目录、kernel.py和资料快照接口。没有内置Python二进制；代码执行不是操作系统隔离。原Notebook可用性探测仍限于受支持Mac ARM64。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：18 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。

运行协议回归使用合成代码；执行这部分测试需要 Python 3。可用 `INKSPACE_TEST_PYTHON` 指定本机测试解释器。测试不会读取用户 Notebook。
