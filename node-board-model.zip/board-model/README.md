# 白板格式与元素

白板 JSON 解析、格式校验、节点与连线操作、笔迹位置及子白板链接。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/board-model
```

```js
const tools = require('@inkspace-modules/board-model');
const board = tools.elements.newBoard('Example', require('node:crypto').randomUUID());
console.log(tools.validation.validateBoard(board));
```

## API 命名空间

- `json` → [源码与函数签名](sources/main/board-json.cjs)
- `validation` → [源码与函数签名](sources/main/board-validation.cjs)
- `elements` → [源码与函数签名](sources/main/board-elements.cjs)
- `navigation` → [源码与函数签名](sources/main/board-navigation.cjs)
- `childLinks` → [源码与函数签名](sources/main/board-child-links.cjs)
- `webURLs` → [源码与函数签名](sources/main/board-web-url.cjs)
- `operations` → [源码与函数签名](sources/main/board-operations.cjs)
- `paste` → [源码与函数签名](sources/main/board-paste.cjs)
- `fileCards` → [源码与函数签名](sources/main/board-file-cards.cjs)
- `sourceResolver` → [源码与函数签名](sources/main/board-source-resolver.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

- `pdf-lib@1.17.1`

## 使用边界

纯格式与元素函数可直接调用；PDF图层相关输入仍按原始数据协议校验，不提供UI或原生PencilKit。 文件变更、粘贴和原生笔迹变换操作需要注入授权资料库、图片解码或原生笔迹桥接口。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
