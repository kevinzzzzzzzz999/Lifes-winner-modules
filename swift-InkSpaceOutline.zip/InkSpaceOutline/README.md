# InkSpaceOutline

Markdown 树形纲要转换。这是SwiftPM源码库，需要解压并加入自己的软件，不包含可直接启动的App或安装包。

## 本包内容

- 原模块名与对外产品名：`InkSpaceOutline`。
- 直接依赖：无其它InkSpace模块。
- 自带target闭包：`InkSpaceOutline`。
- 最低声明平台：macOS 13、iOS/iPadOS 18；Swift 5.9及以上。
- 库源码和资源与整合版模块集合中的对应文件逐字节一致；没有附带构建缓存、账号凭据或用户资料。

## 解压后使用

1. 解压这个ZIP，得到`InkSpaceOutline/Package.swift`和`Sources/`。
2. 在Xcode选择添加本地Swift Package，并选择这个解压后的文件夹。
3. 只选择`InkSpaceOutline`这个library product，代码使用`import InkSpaceOutline`。

也可以在自己的Package.swift中使用本地路径依赖：

```swift
.package(path: "../InkSpaceOutline")
```

自己的target依赖添加：

```swift
.product(name: "InkSpaceOutline", package: "inkspaceoutline")
```

在解压后的包目录运行`swift build`可编译此库。这个源码ZIP不是远程SwiftPM仓库地址；不能将ZIP下载链接当作`.package(url:)`地址。

## 公开API

- `NoteOutline.parse(_:)`
- `encode(titles:edges:)`
- `NoteOutlineNode`

## 依赖与组合

本包只声明一个对外product，依赖target已经一并提供，因此无需安装完整InkSpace应用。多个不同ZIP可能自带相同的共享target，例如`InkSpacePaths`；需要在同一个项目组合这些功能时，使用完整模块集合的清单统一依赖，或统一共享target，不要同时引入重复的同名target。

## 范围与验证

只支持标题和列表形成的树，不包含普通正文Markdown渲染、任意多父图或导图界面。保留1MiB、500节点和12层上限。

整合版的16个Swift产品已通过普通import构建、20项行为测试，以及iOS arm64模拟器无签名构建。本次独立归档逐包检查SwiftPM产品、target依赖和资源闭包；其中六组代表归档另行实际编译。本包未附带或重新执行整合版全部行为测试，具体归档验证结果记入发布清单。未操作真实设备、真实AI服务或Keychain。

采用MIT许可，见LICENSE。
