// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceAI",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceAI", targets: ["InkSpaceAI"])],
    targets: [
        .target(name: "InkSpaceAI", path: "Sources/InkSpaceAI")
    ]
)
