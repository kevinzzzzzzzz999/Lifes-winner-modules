// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceStudy",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceStudy", targets: ["InkSpaceStudy"])],
    targets: [
        .target(name: "InkSpacePaths", path: "Sources/InkSpacePaths"),
        .target(name: "InkSpaceStudy", dependencies: ["InkSpacePaths"], path: "Sources/InkSpaceStudy")
    ]
)
