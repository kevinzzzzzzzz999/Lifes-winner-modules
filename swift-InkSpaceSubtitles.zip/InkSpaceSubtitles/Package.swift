// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceSubtitles",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceSubtitles", targets: ["InkSpaceSubtitles"])],
    targets: [
        .target(name: "InkSpaceSubtitles", path: "Sources/InkSpaceSubtitles")
    ]
)
