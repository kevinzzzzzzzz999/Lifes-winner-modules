// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceOCR",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceOCR", targets: ["InkSpaceOCR"])],
    targets: [
        .target(name: "InkSpaceOCR", path: "Sources/InkSpaceOCR")
    ]
)
