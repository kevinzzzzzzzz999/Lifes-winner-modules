// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceScanPDF",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceScanPDF", targets: ["InkSpaceScanPDF"])],
    targets: [
        .target(name: "InkSpacePaths", path: "Sources/InkSpacePaths"),
        .target(name: "InkSpaceStorage", dependencies: ["InkSpacePaths"], path: "Sources/InkSpaceStorage"),
        .target(name: "InkSpaceScanPDF", dependencies: ["InkSpaceStorage"], path: "Sources/InkSpaceScanPDF")
    ]
)
