// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceTextHistory",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceTextHistory", targets: ["InkSpaceTextHistory"])],
    targets: [
        .target(name: "InkSpaceTextHistory", path: "Sources/InkSpaceTextHistory")
    ]
)
