# 翻译请求与凭据存储接口

请求选区归一化、供应商配置、响应解析、取消/超时及注入式凭据加密存储。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/translation-tools
```

```js
const tools = require('@inkspace-modules/translation-tools');
const request = {requestId:require('node:crypto').randomUUID(), target:'en', text:'Example'};
console.log(tools.service.selection(request).text);
```

## API 命名空间

- `service` → [源码与函数签名](sources/main/translation-service.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

本包不包含账户或密钥，上传和开源源码无需提供任何授权信息。TranslationService通过宿主注入的数据目录与加密接口管理调用时的服务设置；真实联网翻译的认证由使用它的宿主处理。不会用明文存储替代加密接口。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
