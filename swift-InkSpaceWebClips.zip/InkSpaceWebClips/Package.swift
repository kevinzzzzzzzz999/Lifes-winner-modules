// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceWebClips",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceWebClips", targets: ["InkSpaceWebClips"])],
    targets: [
        .target(name: "InkSpaceWebClips", path: "Sources/InkSpaceWebClips")
    ]
)
