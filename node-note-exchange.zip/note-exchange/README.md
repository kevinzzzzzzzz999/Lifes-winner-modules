# 笔记交换与纲要

Markdown/缩进纲要与白板转换、BoardNotes归档解析、对象解码、受限导入导出流程。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/note-exchange
```

```js
const tools = require('@inkspace-modules/note-exchange');
console.log(tools.outline.parseOutline('# Example\n## Section'));
```

## API 命名空间

- `exchange` → [源码与函数签名](sources/main/note-exchange.cjs)
- `outline` → [源码与函数签名](sources/main/note-outline.cjs)
- `archives` → [源码与函数签名](sources/main/boardnotes-zip.cjs)
- `objects` → [源码与函数签名](sources/main/boardnotes-objects.cjs)
- `format` → [源码与函数签名](sources/main/boardnotes-format.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

- `pdf-lib@1.17.1`

## 使用边界

归档与纲要纯函数可直接使用。导入导出类需授权资料库接口；需要选择文件的方法接受调用者传入的dialog接口，未引入Electron。原Worker与相对路径资源一起保留。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
