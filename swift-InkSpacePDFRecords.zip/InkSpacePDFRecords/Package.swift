// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpacePDFRecords",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpacePDFRecords", targets: ["InkSpacePDFRecords"])],
    targets: [
        .target(name: "InkSpacePDFRecords", path: "Sources/InkSpacePDFRecords")
    ]
)
