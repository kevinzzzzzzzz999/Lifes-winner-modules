// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceGeometry",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceGeometry", targets: ["InkSpaceGeometry"])],
    targets: [
        .target(name: "InkSpaceGeometry", path: "Sources/InkSpaceGeometry")
    ]
)
