// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceSpeechText",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceSpeechText", targets: ["InkSpaceSpeechText"])],
    targets: [
        .target(name: "InkSpaceSpeechText", path: "Sources/InkSpaceSpeechText")
    ]
)
