import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {mkdtemp,readFile,realpath} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createServer} from 'vite';
import {PDFDocument,StandardFonts} from 'pdf-lib';
const {chromium}=await import(process.env.INKSPACE_PLAYWRIGHT_MODULE||'playwright');
const ui=fileURLToPath(new URL('../',import.meta.url));
const built=spawnSync(process.execPath,[path.join(ui,'scripts/build.mjs')],{cwd:ui,encoding:'utf8'});if(built.status!==0)throw new Error(built.stdout+built.stderr);
const temp=await mkdtemp(path.join(os.tmpdir(),'inkspace-ui-smoke-'));
const pdf=await PDFDocument.create(),font=await pdf.embedFont(StandardFonts.Helvetica);pdf.addPage([500,700]).drawText('Independent PDF example',{x:40,y:650,font,size:18});const pdfBytes=Buffer.from(await pdf.save());
const server=await createServer({configFile:false,root:ui,cacheDir:path.join(temp,'vite-cache'),publicDir:false,optimizeDeps:{include:['react','react-dom','react-dom/client','react/jsx-runtime','react/jsx-dev-runtime'],noDiscovery:true},server:{host:'127.0.0.1',port:0,strictPort:true,fs:{allow:[ui,await realpath(path.join(ui,'node_modules'))]}},plugins:[{name:'synthetic-pdf',configureServer(server){server.middlewares.use('/sample.pdf',(_request,response)=>{response.setHeader('Content-Type','application/pdf');response.end(pdfBytes);});server.middlewares.use('/math-lab',async(request,response)=>{const file=(request.url||'').split('?')[0].replace(/^\//,'');if(!['simple.html','index.html','engine.js','simple-core.js','simple.js','app.js','simple.css','style.css'].includes(file)){response.statusCode=404;response.end();return;}response.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.css')?'text/css':'text/javascript');response.end(await readFile(path.join(ui,'dist/math-lab',file)));});}}]});
await server.listen();const port=server.httpServer.address().port,url=`http://127.0.0.1:${port}/smoke/index.html`;
const browser=await chromium.launch({headless:true,...(process.env.INKSPACE_BROWSER_CHANNEL?{channel:process.env.INKSPACE_BROWSER_CHANNEL}:{})});let checks=0;
const pure=['CodeEditor','TextBoxEditor','KnowledgeGraph','MindMapEditor','MemoryPalace','KnowledgeWalkthrough','DocumentPreview','FormulaView','CsvPreview','HtmlPreview','StructuredDocumentEditor','PDFPage','ReviewPanel','MathWorkbench'];
const hosted=['KnowledgeSpace','NotebookEditor','QuickNotes','CourseChecklist','Calendar','MediaEditor','PDFReader','BoardViewer','InkReplay','StudyPanel','VideoPlayer','LocalOCR','NoteExchange','FileManagement','TranslationSettings'];
const errors=[];const pages=[];
async function pageFor(entry,host='none'){
 const page=await browser.newPage({viewport:{width:1280,height:900}});pages.push(page);page.on('pageerror',error=>errors.push(`${entry}: ${error.message}`));page.on('console',message=>{if(message.type()==='error')errors.push(`${entry}: ${message.text()}`)});
 await page.route('**/*',route=>{const value=route.request().url();if(value.startsWith(`http://127.0.0.1:${port}/`)||value.startsWith('data:')||value.startsWith('blob:'))return route.continue();errors.push(`${entry}: unexpected remote request`);return route.abort();});
 await page.goto(`${url}?entry=${entry}&host=${host}`,{waitUntil:'networkidle'});assert.equal(await page.title(),'InkSpace UI independent smoke');await page.locator('[data-inkspace-module]').waitFor();assert.equal(await page.locator('vite-error-overlay').count(),0);return page;
}
try{
 for(const entry of pure){const page=await pageFor(entry);assert.equal(await page.locator('[data-inkspace-ui-error="render"]').count(),0,entry);assert.equal(await page.locator('[data-inkspace-host-error="configuration"]').count(),0,entry);if(entry==='PDFPage')await page.locator('canvas[data-pdf-ready="true"]').waitFor();
  if(entry==='CodeEditor'){await page.locator('.cm-content').fill('print("changed")');await page.waitForFunction(()=>document.querySelector('#result')?.textContent?.includes('changed'));}
  if(entry==='MemoryPalace'){await page.getByRole('button',{name:'sample.md',exact:true}).press('Enter');await page.waitForFunction(()=>document.querySelector('#result')?.textContent?.includes('sample.md'));}
  if(entry==='KnowledgeWalkthrough'){await page.getByTestId('city-first-person').click();assert.equal(await page.getByTestId('knowledge-city').getAttribute('data-camera-mode'),'first');await page.screenshot({path:path.join(temp,'walkthrough.png')});}
  if(entry==='MathWorkbench'){const frame=page.frameLocator('iframe');await frame.locator('body').waitFor();assert.ok((await frame.locator('body').innerText()).length>20);}
  checks++;await page.close();
 }
 for(const entry of hosted){const page=await pageFor(entry);await page.locator('[data-inkspace-host-error="configuration"]').waitFor();assert.match(await page.locator('[role="alert"]').innerText(),/No full-app fallback or sample data/);checks++;await page.close();}
 for(const entry of hosted){const page=await pageFor(entry,'provided');assert.equal(await page.locator('[data-inkspace-host-error="configuration"]').count(),0,entry);assert.equal(await page.locator('[data-inkspace-ui-error="render"]').count(),0,entry);
  if(entry==='QuickNotes'){await page.getByRole('textbox',{name:'Note text'}).fill('A standalone saved note');await page.getByTestId('quick-note-save').click();await page.locator('.quick-note-item').filter({hasText:'A standalone saved note'}).waitFor();assert.ok(await page.evaluate(()=>window.smokeState.files().some(([,text])=>text.includes('A standalone saved note'))));await page.screenshot({path:path.join(temp,'quick-notes.png')});}
  if(entry==='KnowledgeSpace'){await page.getByTestId('space-3d').click();await page.getByTestId('palace').waitFor();}
  checks++;await page.close();
 }
 assert.deepEqual(errors,[]);console.log(JSON.stringify({status:'passed',mountChecks:checks,entries:pure.length+hosted.length,pure:pure.length,hosted:hosted.length,browser:'Playwright (Browser plugin not available)',viewports:['1280x900'],evidenceDirectory:temp,limits:'Host fixtures use isolated synthetic memory storage; no Python, FFmpeg, native OCR, AI account or private vault execution claimed.'}));
}finally{for(const page of pages)if(!page.isClosed())await page.close();await browser.close();await server.close();}
