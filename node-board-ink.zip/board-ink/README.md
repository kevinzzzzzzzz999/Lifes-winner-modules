# 白板坐标与笔迹回放

合并位置、笔迹裁切路径、绘制计划、回放时间线与高清PDF裁块计划。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/board-ink
```

```js
const tools = require('@inkspace-modules/board-ink');
console.log(tools.placement.validMergeBounds({x:0,y:0,width:100,height:100}));
```

## API 命名空间

- `placement` → [源码与函数签名](sources/renderer/board-merge-placement.ts)
- `clip` → [源码与函数签名](sources/renderer/board-ink-clip.ts)
- `paint` → [源码与函数签名](sources/renderer/board-ink-paint.ts)
- `exportInk` → [源码与函数签名](sources/renderer/board-export-ink.ts)
- `replay` → [源码与函数签名](sources/renderer/ink-replay.ts)
- `replayCamera` → [源码与函数签名](sources/renderer/ink-replay-camera.ts)
- `replayPaint` → [源码与函数签名](sources/renderer/replay-paint.ts)
- `replayDisplay` → [源码与函数签名](sources/renderer/replay-display.ts)
- `pdfResolution` → [源码与函数签名](sources/renderer/board-pdf-resolution.ts)
- `pdfProgressive` → [源码与函数签名](sources/renderer/board-pdf-progressive.ts)
- `childModel` → [源码与函数签名](sources/renderer/child-board-model.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

坐标和时间线计算不需要浏览器；paint/export中实际Canvas绘制接口需要调用者提供CanvasRenderingContext2D，未附带画布UI。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：17 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
