# 本地文件与原子写入

相对路径校验、UTF-8解码、排他持久写入、文件身份检查、受限流复制、最近目录及诊断存储。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/file-storage
```

```js
const tools = require('@inkspace-modules/file-storage');
console.log(tools.paths.relativePath('notes/example.md'));
// await tools.storage.durableWrite(newFilePath, Buffer.from('Example'));
```

## API 命名空间

- `paths` → [源码与函数签名](sources/main/vault-path.cjs)
- `storage` → [源码与函数签名](sources/main/vault-service.cjs)
- `streams` → [源码与函数签名](sources/main/exchange-stream.cjs)
- `identity` → [源码与函数签名](sources/main/exchange-file-identity.cjs)
- `exports` → [源码与函数签名](sources/main/source-file-export.cjs)
- `recent` → [源码与函数签名](sources/main/recent-vaults.cjs)
- `diagnostics` → [源码与函数签名](sources/main/diagnostics.cjs)
- `actions` → [源码与函数签名](sources/main/file-context-actions.cjs)
- `watchLifecycle` → [源码与函数签名](sources/main/vault-watch-lifecycle.cjs)
- `fileManagement` → [源码与函数签名](sources/main/vault-file-management.cjs)
- `watch` → [源码与函数签名](sources/main/vault-watch.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

只抽取VaultService的原有独立函数，不含完整应用资料库类。durableWrite以wx排他创建新文件并fsync，绝不是覆盖写入。最近目录/诊断/文件动作类需传入数据目录、授权资料库或宿主动作接口。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
