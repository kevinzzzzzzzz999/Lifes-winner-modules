# 媒体工程与字幕

剪辑项目验证、混音/速度/FFmpeg参数、字幕格式与侧车记录、视频流访问和播放状态逻辑。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/media-tools
```

```js
const tools = require('@inkspace-modules/media-tools');
console.log(tools.format.clipDuration({start:0,end:10,speed:2}));
```

## API 命名空间

- `format` → [源码与函数签名](sources/main/media-editor-format.cjs)
- `compose` → [源码与函数签名](sources/main/media-editor-compose.cjs)
- `captions` → [源码与函数签名](sources/main/media-editor-captions.cjs)
- `subtitleFormat` → [源码与函数签名](sources/main/subtitle-format-validation.cjs)
- `subtitles` → [源码与函数签名](sources/main/video-subtitles.cjs)
- `video` → [源码与函数签名](sources/main/video-service.cjs)
- `controls` → [源码与函数签名](sources/renderer/video-controls.ts)
- `subtitlePersistence` → [源码与函数签名](sources/renderer/video-subtitle-persistence.ts)
- `editorModel` → [源码与函数签名](sources/renderer/media-editor-model.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

项目/参数/字幕验证可直接使用；媒体文件服务需授权资料库。字幕实际绘制需要注入离屏浏览窗口或绘制器，未包含完整编辑UI、FFmpeg可执行文件和编码器。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
