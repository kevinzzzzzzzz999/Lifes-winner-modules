# InkSpaceMediaTimeline

音视频工程模型与时间线计算。这是SwiftPM源码库，需要解压并加入自己的软件，不包含可直接启动的App或安装包。

## 本包内容

- 原模块名与对外产品名：`InkSpaceMediaTimeline`。
- 直接依赖：无其它InkSpace模块。
- 自带target闭包：`InkSpaceMediaTimeline`。
- 最低声明平台：macOS 13、iOS/iPadOS 18；Swift 5.9及以上。
- 库源码和资源与整合版模块集合中的对应文件逐字节一致；没有附带构建缓存、账号凭据或用户资料。

## 解压后使用

1. 解压这个ZIP，得到`InkSpaceMediaTimeline/Package.swift`和`Sources/`。
2. 在Xcode选择添加本地Swift Package，并选择这个解压后的文件夹。
3. 只选择`InkSpaceMediaTimeline`这个library product，代码使用`import InkSpaceMediaTimeline`。

也可以在自己的Package.swift中使用本地路径依赖：

```swift
.package(path: "../InkSpaceMediaTimeline")
```

自己的target依赖添加：

```swift
.product(name: "InkSpaceMediaTimeline", package: "inkspacemediatimeline")
```

在解压后的包目录运行`swift build`可编译此库。这个源码ZIP不是远程SwiftPM仓库地址；不能将ZIP下载链接当作`.package(url:)`地址。

## 公开API

- `MediaProject.validate/duration/clipStarts/audioHeadroom`
- `MediaSource`
- `MediaClip`
- `MediaCaptionImporter.parse`

## 依赖与组合

本包只声明一个对外product，依赖target已经一并提供，因此无需安装完整InkSpace应用。多个不同ZIP可能自带相同的共享target，例如`InkSpacePaths`；需要在同一个项目组合这些功能时，使用完整模块集合的清单统一依赖，或统一共享target，不要同时引入重复的同名target。

## 范围与验证

模型、范围验证、转场/混音数值及字幕解析可独立复用；不包含AVFoundation渲染、媒体素材读取或剪辑界面。先validate再使用派生播放/混音计算。

整合版的16个Swift产品已通过普通import构建、20项行为测试，以及iOS arm64模拟器无签名构建。本次独立归档逐包检查SwiftPM产品、target依赖和资源闭包；其中六组代表归档另行实际编译。本包未附带或重新执行整合版全部行为测试，具体归档验证结果记入发布清单。未操作真实设备、真实AI服务或Keychain。

采用MIT许可，见LICENSE。
