// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceChecklist",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceChecklist", targets: ["InkSpaceChecklist"])],
    targets: [
        .target(name: "InkSpaceChecklist", path: "Sources/InkSpaceChecklist", resources: [.process("Resources")])
    ]
)
