# 清单日历与ICS

任务清单、快速笔记、日历模型、ICS导入导出、日历文件及提醒调度。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/task-calendar
```

```js
const tools = require('@inkspace-modules/task-calendar');
const list = tools.checklists.createChecklist('Example');
console.log(tools.checklists.addTask(list, 'Read the example').tasks.length);
```

## API 命名空间

- `calendar` → [源码与函数签名](sources/renderer/calendar-model.ts)
- `ics` → [源码与函数签名](sources/renderer/calendar-ics.ts)
- `checklists` → [源码与函数签名](sources/renderer/course-checklist.ts)
- `checklistLocations` → [源码与函数签名](sources/renderer/checklist-location.ts)
- `quickNotes` → [源码与函数签名](sources/renderer/quick-notes.ts)
- `courseCalendar` → [源码与函数签名](sources/renderer/course-calendar.ts)
- `calendarStore` → [源码与函数签名](sources/renderer/calendar-store.ts)
- `calendarFiles` → [源码与函数签名](sources/main/calendar-service.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

纯模型与ICS可直接使用；文件存储需注入授权资料库；提醒需注入通知回调/数据目录，不会自动申请系统权限。部分浏览器偏好接口需调用者提供存储。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：13 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
