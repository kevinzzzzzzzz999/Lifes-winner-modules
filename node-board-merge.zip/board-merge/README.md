# 白板合并与撤回

来源检查、笔迹平移、合并结果、事务撤回、历史快照与编辑器快照接受规则。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/board-merge
```

```js
const tools = require('@inkspace-modules/board-merge');
const ink = {version:1, strokes:[{points:[[1,2,3]], color:'#000000'}]};
console.log(tools.merge.translateWeb(ink, 10, 20).strokes[0].points);
```

## API 命名空间

- `merge` → [源码与函数签名](sources/main/board-merge.cjs)
- `history` → [源码与函数签名](sources/main/board-history-service.cjs)
- `sessions` → [源码与函数签名](sources/renderer/board-merge-tabs.ts)
- `childSession` → [源码与函数签名](sources/renderer/child-board-session.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

buildMerged等纯函数直接使用；mergeBoards/undoBoardMerge/BoardHistoryService需要调用者注入资料库、锁、快照和保存接口，依原实现拒绝冲突。未附带完整VaultService或原生笔迹可执行文件。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：6 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
