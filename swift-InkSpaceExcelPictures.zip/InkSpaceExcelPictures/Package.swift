// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceExcelPictures",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceExcelPictures", targets: ["InkSpaceExcelPictures"])],
    targets: [
        .target(name: "InkSpaceExcelPictures", path: "Sources/InkSpaceExcelPictures")
    ]
)
