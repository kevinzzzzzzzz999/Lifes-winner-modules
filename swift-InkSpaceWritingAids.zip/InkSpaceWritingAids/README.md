# InkSpaceWritingAids

辅助书写与演示：停留直线与六形拟合、波浪/填色、高亮置底、激光、胶带、文字卡及可选iPad系统手写输入；附Mac交互画布。。这是SwiftPM源码库，需要解压并加入自己的软件，不包含可直接启动的App或安装包。

## 本包内容

- 原模块名与对外产品名：`InkSpaceWritingAids`。
- 直接依赖：无其它InkSpace模块。
- 自带target闭包：`InkSpaceWritingAids`。
- 最低声明平台：macOS 13、iOS/iPadOS 18；Swift 5.9及以上。
- 库源码和资源与整合版模块集合中的对应文件逐字节一致；没有附带构建缓存、账号凭据或用户资料。

## 解压后使用

1. 解压这个ZIP，得到`InkSpaceWritingAids/Package.swift`和`Sources/`。
2. 在Xcode选择添加本地Swift Package，并选择这个解压后的文件夹。
3. 只选择`InkSpaceWritingAids`这个library product，代码使用`import InkSpaceWritingAids`。

## 先运行随包示例 / Run the included example

本ZIP的`Example/`包含独立macOS示例，只需要安装带Swift工具链的Xcode，不需要完整InkSpace、账号或密钥。在本包解压目录运行：

```sh
bash Example/script/build_and_run.sh
```

也可用`swift run --package-path Example WritingAidsDemo`直接从SwiftPM启动。

示例源码和详细操作见`Example/README.md`。这是从源码启动的示例，不是已签名安装包；iPhone/iPad使用方式和平台边界见下方说明。

也可以在自己的Package.swift中使用本地路径依赖：

```swift
.package(path: "../InkSpaceWritingAids")
```

自己的target依赖添加：

```swift
.product(name: "InkSpaceWritingAids", package: "inkspacewritingaids")
```

在解压后的包目录运行`swift build`可编译此库。这个源码ZIP不是远程SwiftPM仓库地址；不能将ZIP下载链接当作`.package(url:)`地址。

## 公开API

- `HeldLineTracker`
- `HeldShapeTracker`
- `WritingAidShape`
- `WritingAidStrokeGeometry`
- `WritingAidHighlighterUnderlay`
- `WritingAidMode`
- `WritingAidSettings`
- `WritingAidSessionToken`
- `WritingAidPoint`
- `WritingAidColor`
- `WritingAidTape`
- `WritingAidTapeDocument`
- `WritingAidTapeGeometry`
- `WritingAidTapeRepository`
- `WritingAidLaserTrail`
- `WritingAidLaserPresentation`
- `WritingAidTextDraft`
- `WritingAidTextSubmission`
- `WritingAidScribbleInput (iOS)`
- `WritingAidScribbleCardInput (iOS)`
- `WritingAidError`

## 用法示例

```swift
import Foundation
import CoreGraphics
import InkSpaceWritingAids

// Feed screen-space points and a monotonic timestamp from your own input system.
var tracker = HeldLineTracker(point: CGPoint(x: 40, y: 80), time: 0)
tracker.append(CGPoint(x: 120, y: 81), time: 0.1)
tracker.append(CGPoint(x: 240, y: 80), time: 0.2)
let fitted = tracker.confirmIfQuiet(at: 0.9, duration: 0.65)
if let fitted {
    let projected = WritingAidStrokeGeometry.projectedOntoLine(tracker.samples, line: fitted)
    print(projected?.count ?? 0)
}

let wave = try WritingAidStrokeGeometry.wavy(
    points: [CGPoint(x: 40, y: 100), CGPoint(x: 300, y: 100)],
    width: 3, wavelength: 24, amplitude: 5,
    worldSize: CGSize(width: 1000, height: 1000))

let boardID = UUID()
let tape = WritingAidTape(points: [.init(x: 40, y: 100), .init(x: 300, y: 100)],
                          width: 24, color: .init(red: 0.2, green: 0.35, blue: 0.85))
let document = WritingAidTapeDocument(boardID: boardID, tapes: [tape])
let bytes = try document.encoded() // Memory only. The host chooses whether/where to write.
let restored = try WritingAidTapeDocument.decode(bytes, boardID: boardID)
let revealed = try restored.toggling(tape.id)
print(wave.count, revealed.tapes[0].isRevealed)
```

Mac 交互示例的可执行产品名为 `WritingAidsDemo`。进入示例中包含 `Package.swift`、`README.md` 的目录，运行 `bash script/build_and_run.sh`；脚本构建并启动一个有独立名称的 `.app`。源码仓库中该目录为 `samples/writing-aids`，独立下载包中为 `Example`。只需 Xcode 命令行开发工具，不需要完整 InkSpace。示例目录内的 README 说明每个工具和 JSON 导出方法。

## 依赖与组合

本包只声明一个对外product，依赖target已经一并提供，因此无需安装完整InkSpace应用。多个不同ZIP可能自带相同的共享target，例如`InkSpacePaths`；需要在同一个项目组合这些功能时，使用完整模块集合的清单统一依赖，或统一共享target，不要同时引入重复的同名target。

## 范围与验证

Core returns geometry/value state; host owns native PKStroke pressure, transform, undo and insertion. Scribble uses a system UITextInput surface on supported iPad devices; no bundled OCR. Real Apple Pencil/device recognition has not been tested. macOS SwiftUI demo uses vector highlighter/fill rendering; it does not reproduce PencilKit texture. Tape v1 supports board-space only; card-relative anchors are explicitly rejected. All filesystem work is opt-in, at a host-selected trusted local directory; no networking/default preferences reads. Demo exports its own bounded versioned JSON, not original InkSpace boards; laser/draft/undo state excluded.

初次抽取时的整合版16个Swift产品曾通过普通import构建、20项行为测试和iOS arm64模拟器无签名构建；后续源码更新不自动继承这些历史结论。独立归档重建会逐包检查SwiftPM产品、target依赖和资源闭包；额外编译由维护者显式选择。本包未附带或自动重新执行整合版全部行为测试，实际验证结果由维护者记入发布清单。未操作真实设备、真实AI服务或Keychain。

采用MIT许可，见LICENSE。
