# 学习卡片与复习

卡片/填空格式、学习事件投影、CSV/TSV问答导入去重、复习记录与题纲。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/study-tools
```

```js
const tools = require('@inkspace-modules/study-tools');
console.log(tools.model.clozes('Example {{answer}}'));
```

## API 命名空间

- `model` → [源码与函数签名](sources/main/study-model.cjs)
- `store` → [源码与函数签名](sources/main/study-service.cjs)
- `transferModel` → [源码与函数签名](sources/main/study-transfer-model.cjs)
- `transfer` → [源码与函数签名](sources/main/study-transfer-service.cjs)
- `reviews` → [源码与函数签名](sources/main/review-service.cjs)
- `outline` → [源码与函数签名](sources/renderer/study-outline.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

格式与投影不需要UI；卡片/复习存储需授权资料库与快照/锁接口，图片解码需注入解码器。不会附带实际学习记录。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
