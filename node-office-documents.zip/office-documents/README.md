# Office文档模型

基础DOCX/PPTX生成和自身模型回读、外部文档只读预览、嵌入图片与ZIP容量检查。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/office-documents
```

```js
const tools = require('@inkspace-modules/office-documents');
const model = {version:1, format:'docx', title:'Example', blocks:[{kind:'paragraph', text:'Example text'}]};
tools.office.createOffice(model).then(bytes => console.log(bytes.length));
```

## API 命名空间

- `model` → [源码与函数签名](sources/main/editable-document-model.cjs)
- `office` → [源码与函数签名](sources/main/editable-office.cjs)
- `docxPreview` → [源码与函数签名](sources/main/docx-preview.cjs)
- `images` → [源码与函数签名](sources/main/office-embedded-images.cjs)
- `legacyDoc` → [源码与函数签名](sources/main/legacy-doc-preview.cjs)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

- `@xmldom/xmldom@0.8.15`
- `jszip@3.10.2`
- `mammoth@1.12.3`

## 使用边界

依赖JSZip、mammoth与XML解析器。仅支持现有基础Office模型，不声称完整还原Word/PowerPoint排版。旧.doc转换调用Mac系统textutil，其他平台需转换器。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
