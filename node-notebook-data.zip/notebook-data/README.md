# Notebook数据与格式

CSV/TSV解析、Excel工作簿Worker、Notebook格式/容量/输出校验、目录与运行事件归并。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/notebook-data
```

```js
const tools = require('@inkspace-modules/notebook-data');
console.log(tools.delimited.parseDelimited('name,count\nexample,2', ',').rows);
```

## API 命名空间

- `workbooks` → [源码与函数签名](sources/main/notebook-data.cjs)
- `delimited` → [源码与函数签名](sources/renderer/data-file-parsers.ts)
- `format` → [源码与函数签名](sources/shared/notebook-format.ts)
- `actions` → [源码与函数签名](sources/renderer/notebook-actions.ts)
- `outline` → [源码与函数签名](sources/renderer/notebook-outline.ts)
- `html` → [源码与函数签名](sources/renderer/notebook-html-format.ts)
- `sessions` → [源码与函数签名](sources/renderer/notebook-session.ts)
- `events` → [源码与函数签名](sources/renderer/notebook-events.ts)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

- `@xmldom/xmldom@0.8.15`
- `jszip@3.10.2`
- `marked@18.0.13`

## 使用边界

Excel Worker及其相对路径资源一起打包，使用Node worker_threads；需要注入文件快照接口。包含SheetJS原始公开脚本和Apache-2.0许可。不会运行Notebook代码。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：46 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
