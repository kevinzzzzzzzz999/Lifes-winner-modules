// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceMediaTimeline",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceMediaTimeline", targets: ["InkSpaceMediaTimeline"])],
    targets: [
        .target(name: "InkSpaceMediaTimeline", path: "Sources/InkSpaceMediaTimeline")
    ]
)
