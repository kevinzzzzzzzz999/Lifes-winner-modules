// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "InkSpaceWritingAids",
    platforms: [.macOS(.v13), .iOS("18.0")],
    products: [.library(name: "InkSpaceWritingAids", targets: ["InkSpaceWritingAids"])],
    targets: [
        .target(name: "InkSpaceWritingAids", path: "Sources/InkSpaceWritingAids")
    ]
)
