# 离线数值计算

表达式解析、采样、微积分近似、回归/时间序列、现金流/贷款/债券/期权等教育数值函数。

## 独立使用

本包可单独复制并本地安装，不需要完整 InkSpace 应用。尚未发布到 npm；包名只供本地依赖引用。

```sh
npm install ./packages/math-lab
```

```js
const tools = require('@inkspace-modules/math-lab');
const f = tools.engine.compile('x*x');
console.log(f({x:3}));
```

## API 命名空间

- `engine` → [源码与函数签名](sources/math-lab/engine.js)
- `simple` → [源码与函数签名](sources/math-lab/simple-core.js)

原始函数签名保留在 `sources/`；`lib/` 中的 TypeScript 已转换为 CommonJS，可直接 require，无需现场编译。

## 依赖

Node.js 24.15 或以上。

无外部 npm 依赖，只使用 Node.js 标准库。

## 使用边界

现有双精度教育计算引擎；没有实时市场数据、联网、符号代数或数值精度保证。独立网页资源同时提供，财务公式不是投资建议。

服务类仅保存调用者指定的位置；应传入独立测试目录和明确授权的输入。模块不附带用户笔记、登录状态、设备标识或服务密钥。

## 验证

运行 `npm test`。相关应用回归已迁移到本包的 `test/`，直接通过本包副本调用；未迁移的整应用验收不属于此包的通过声明。单独包加载和功能检查结果以根目录 `modules.json` 的验证记录为准。 本次已在仓库外的独立副本验证：1 项测试通过，0 失败、0 跳过。

## 许可

原创代码采用本包 `LICENSE` 中的 MIT 许可。第三方 npm 依赖和保留在 vendor 目录的组件继续遵守各自许可。
